class PyMybatisEx(Exception):
    pass
